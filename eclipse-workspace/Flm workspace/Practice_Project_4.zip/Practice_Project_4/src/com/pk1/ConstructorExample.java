package com.pk1;

public class ConstructorExample {
    private int value;

    // Default constructor
    public ConstructorExample() {
        System.out.println("Default Constructor called");
        this.value = 0;
    }

    // Parameterized constructor
    public ConstructorExample(int value) {
        System.out.println("Parameterized Constructor called");
        this.value = value;
    }



    public int getValue() {
        return value;
    }

    public static void main(String[] args) {
        // Creating objects using different constructors
        ConstructorExample obj1 = new ConstructorExample();
        ConstructorExample obj2 = new ConstructorExample(10);

        
        // Accessing values of the objects
        System.out.println("Value of obj1: " + obj1.getValue());
        System.out.println("Value of obj2: " + obj2.getValue());
       
    }
}

